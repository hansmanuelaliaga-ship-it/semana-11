n1=int(input("Ingrese primer numero: "))
for i in range (0 , 11, 1):
    multiplicacion = n1 * i
    print(n1, "x", i, "=", multiplicacion)