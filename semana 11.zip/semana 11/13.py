cantidad = 0
numero = 1
while numero <= 100:
    if numero % 2 == 0:
        cantidad += 1
    numero += 1
print("Cantidad de números pares:", cantidad)