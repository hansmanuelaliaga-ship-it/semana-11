suma = 0
i = 0
while i < 10:
    n=int(input("ingrese un numero: "))
    suma= suma + n
    i = i + 1
print("la suma total es: ",suma)