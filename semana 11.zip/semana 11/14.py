suma = 0
contador = 1
while contador <= 5:
    nota = float(input("Ingrese una nota: "))
    suma += nota
    contador += 1
promedio = suma / 5
print("Promedio:", promedio)