numero = int(input("Ingrese un número: "))
fac = 1
for i in range(1,numero+1):
    fac = fac * i
print("Factorial =", fac)