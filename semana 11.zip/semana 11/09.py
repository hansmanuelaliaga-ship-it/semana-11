n=int(input("Ingrese un numero entero xd: "))
i = 0
while i < n:
    i = i +1
    print(i)