resta=51
for i in range(1, 51):
    resta=resta-1
    print(resta)